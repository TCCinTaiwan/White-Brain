##Description#
	jPainter is a brower-based painting tool,based on HTML5 Canvas and jquery. 
## How to Run it#
   Just open jPainter.html by Internet Explorer,Firfox and etc.

Have fun !!!